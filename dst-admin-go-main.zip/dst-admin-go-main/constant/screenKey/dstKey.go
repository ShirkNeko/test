package screenKey

func Key(level, clusterName string) string {
	return "DST_8level_" + level + "_" + clusterName
}
