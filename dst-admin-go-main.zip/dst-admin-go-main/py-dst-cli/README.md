# py-dst-cli

主要获取 `饥荒世界设置文件` 和 `饥荒当前版本文件`
pip freeze > requirements.txt
## 安装依赖
```
创建虚拟环境
python3 -m venv env

激活虚拟环境
source env/bin/activate

安装依赖库
pip install -r requirements.txt

退出虚拟环境
deactivate
```

## 获取 饥荒 worldgen_customization.tex

1. 直接从饥荒安装的位置 获取到

```
/data/images
```
2. 通过steamcmd 下载解压得到


