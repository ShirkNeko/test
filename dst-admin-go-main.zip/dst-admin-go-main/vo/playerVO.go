package vo

type PlayerVO struct {
	Key  string `json:"key"`
	Day  string `json:"day"`
	Name string `json:"name"`
	KuId string `json:"kuId"`
	Role string `json:"role"`
}
