package message

const (
	Text_Type      = 1
	Kmarkdown_Type = 9
	Card_Type      = 10
)
